# Minimal CRDs

These CRDs omit schema validation.
